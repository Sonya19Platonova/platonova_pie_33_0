function getTextBoxValue2() {
    let n = parseFloat(prompt("Введите количество чисел в наборе N (N > 0):"));
    const resultContainer = document.getElementById("resultDisplay2");

    if (n <= 0) {
        resultContainer.textContent = "Введите корректное значение N (N > 0)!";
    } else {
        let proizvedenie = 1;
        for (let i = 1; i <= n; i++) {
            let num = parseFloat(prompt("Введите число " + i + ":"));
            proizvedenie *= num;
        }
        resultContainer.textContent = "Произведение чисел равно: " + proizvedenie;
    }
}
