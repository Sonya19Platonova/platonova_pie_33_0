﻿fetch('https://dummyjson.com/products')
.then(res => res.json())
.then(data => {
    const productsContainer = document.getElementById('products');

    // Создание массивов для хранения продуктов по категориям
    const beautyProducts = [];
    const fragrancesProducts = [];
    const furnitureProducts = [];
    const groceriesProducts = [];
    
    // Сохранение всех продуктов и их категорий
    const allProducts = data.products.map(product => {
        const { thumbnail, title, category, price } = product;

        // Группировка продуктов по категориям
        if (category === 'beauty') beautyProducts.push(product);
        else if (category === 'fragrances') fragrancesProducts.push(product);
        else if (category === 'furniture') furnitureProducts.push(product);
        else if (category === 'groceries') groceriesProducts.push(product);

        return { thumbnail, title, category, price };
    });

    // Функция для отображения продуктов
    const displayProducts = (products) => {
        productsContainer.innerHTML = ''; // Очистка контейнера
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';

            const imgElement = document.createElement('img');
            imgElement.src = product.thumbnail;
            imgElement.alt = product.title;
            imgElement.style.width = '175px';

            const titleElement = document.createElement('h2');
            titleElement.textContent = product.title;

            const categoryElement = document.createElement('h6');
            categoryElement.textContent = `Категория: ${product.category}`;

            const priceElement = document.createElement('p');
            priceElement.textContent = `Цена: $${product.price}`;

            

            // Добавление элементов в productDiv
            productDiv.appendChild(imgElement);
            productDiv.appendChild(titleElement);
            productDiv.appendChild(categoryElement);
            productDiv.appendChild(priceElement);


            // Добавление productDiv в контейнер
            productsContainer.appendChild(productDiv);
        });
    };

    // Функции для показа продуктов по категориям
    window.showAll = () => displayProducts(allProducts);
    window.showCategory = (category) => {
        let selectedProducts;
        switch(category) {
            case 'beauty':
                selectedProducts = beautyProducts;
                break;
            case 'fragrances':
                selectedProducts = fragrancesProducts;
                break;
            case 'furniture':
                selectedProducts = furnitureProducts;
                break;
            case 'groceries':
                selectedProducts = groceriesProducts;
                break;
        }
        displayProducts(selectedProducts);
    };

    // Отобразить все продукты изначально
    displayProducts(allProducts);
});
