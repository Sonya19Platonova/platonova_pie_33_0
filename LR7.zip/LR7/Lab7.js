﻿fetch('https://dummyjson.com/products')
.then(res => res.json())
.then(data => {
    const productsContainer = document.getElementById('products');
    const detailsContainer = document.getElementById('details-content');
    const productDetailsContainer = document.getElementById('product-details');

    // Создание массивов для хранения продуктов по категориям
    const beautyProducts = [];
    const fragrancesProducts = [];
    const furnitureProducts = [];
    const groceriesProducts = [];
    
    // Сохранение всех продуктов и их категорий
    const allProducts = data.products.map(function(product) {
        const id = product.id;
        const thumbnail = product.thumbnail;
        const title = product.title;
        const category = product.category;
        const price = product.price;

        // Группировка продуктов по категориям
        switch (category) {
            case 'beauty':
                beautyProducts.push(product);
                break;
            case 'fragrances':
                fragrancesProducts.push(product);
                break;
            case 'furniture':
                furnitureProducts.push(product);
                break;
            case 'groceries':
                groceriesProducts.push(product);
                break;
        }

        return { id, thumbnail, title, category, price };
    });

    // Функция для отображения продуктов
    const displayProducts = function(products) {
        productsContainer.innerHTML = ''; // Очистка контейнера
        products.forEach(function(product) {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';

            const imgElement = document.createElement('img');
            imgElement.src = product.thumbnail;
            imgElement.alt = product.title;
            imgElement.style.width = '175px';

            const titleElement = document.createElement('h2');
            titleElement.textContent = product.title;

            const categoryElement = document.createElement('h6');
            categoryElement.textContent = 'Категория: ' + product.category;

            const priceElement = document.createElement('p');
            priceElement.textContent = 'Цена: $' + product.price;

            // Добавление обработчика события для отображения полной информации о товаре
            titleElement.style.cursor = 'pointer'; // Указатель на элемент
            titleElement.onclick = () => {
                fetch(`https://dummyjson.com/products/${product.id}`)
                    .then(res => res.json())
                    .then(productDetails => {
                        displayProductDetails(productDetails);
                    });
            };

            // Добавление элементов в productDiv
            productDiv.appendChild(imgElement);
            productDiv.appendChild(titleElement);
            productDiv.appendChild(categoryElement);
            productDiv.appendChild(priceElement);

            // Добавление productDiv в контейнер
            productsContainer.appendChild(productDiv);
        });
    };

    function displayProductDetails(product) {
        // Очищаем предыдущие данные
        detailsContainer.innerHTML = '';
    
        // Создаем элементы для отображения полной информации
        var infoElements = [
            `ID: ${product.id}`,
            `Название: ${product.title}`,
            `Описание: ${product.description}`,
            `Категория: ${product.category}`,
            `Цена: $${product.price}`,
            `Скидка: ${product.discountPercentage}%`,
            `Рейтинг: ${product.rating}`,
            `В наличии: ${product.stock}`,
            `Бренд: ${product.brand}`,
            `SKU: ${product.sku}`,
            `Вес: ${product.weight}`,
            `Гарантия: ${product.warrantyInformation}`,
            `Доставка: ${product.shippingInformation}`,
            `Статус: ${product.availabilityStatus}`
        ];
    
        // Выводим информацию о товарах
        infoElements.forEach(function(info) {
            var infoElement = document.createElement('p');
            infoElement.textContent = info;
            detailsContainer.appendChild(infoElement);
        });
    
        // Выводим отзывы
        var reviewsTitle = document.createElement('h3');
        reviewsTitle.textContent = 'Отзывы';
        detailsContainer.appendChild(reviewsTitle);
    
        product.reviews.forEach(function(review) {
            var reviewElement = document.createElement('div');
            reviewElement.innerHTML = `
                <strong>Рейтинг:</strong> ${review.rating}<br>
                <strong>Комментарий:</strong> ${review.comment}<br>
                <strong>Дата:</strong> ${review.date}<br>
                <strong>Имя рецензента:</strong> ${review.reviewerName}<br>
                <strong>Email рецензента:</strong> ${review.reviewerEmail}<br>
                <hr>
            `;
            detailsContainer.appendChild(reviewElement);
        });
    
        // Отображаем миниатюру
        var imgElement = document.createElement('img');
        imgElement.src = product.thumbnail;
        imgElement.alt = product.title;
        imgElement.style.width = '175px';
        detailsContainer.appendChild(imgElement);
    
        // Скрываем список продуктов и показываем детали
        document.getElementById('products').style.display = 'none';
        productDetailsContainer.style.display = 'block';
    }
    
    
    // Обработчик для кнопки "Скрыть информацию"
document.getElementById('hide-details-button').onclick = function() {
    productDetailsContainer.style.display = 'none';
    productsContainer.style.display = 'grid'; // Показываем сетку продуктов
    productsContainer.style.gridTemplateColumns = 'repeat(4, 1fr)'; // Устанавливаем 4 столбца
};

// Функции для показа продуктов по категориям
window.showAll = function() {
    displayProducts(allProducts);
};

window.showCategory = function(category) {
    let selectedProducts;
    switch(category) {
        case 'beauty':
            selectedProducts = beautyProducts;
            break;
        case 'fragrances':
            selectedProducts = fragrancesProducts;
            break;
        case 'furniture':
            selectedProducts = furnitureProducts;
            break;
        case 'groceries':
            selectedProducts = groceriesProducts;
            break;
    }
    displayProducts(selectedProducts);
};


    // Отобразить все продукты изначально
    displayProducts(allProducts);
});
